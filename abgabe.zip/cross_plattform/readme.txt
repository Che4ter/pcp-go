// Windows
go build .\main.go .\main_windows.go

// Linux
go build .\main.go .\main_linuxlike.go