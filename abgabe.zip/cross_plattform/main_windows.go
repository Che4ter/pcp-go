package main

func GetCommand() []string {
	return []string{"ipconfig", "/all"}
}