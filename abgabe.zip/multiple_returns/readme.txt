Achtung! Das cmdlet schliesst sich bewusst sofort!
Sonst funktioniert diese nicht in den Präsentation.